package c_barracksWars.contracts;

public interface UnitFactory {

    Unit createUnit(String unitType);
}