package c_barracksWars.contracts;

public interface Runnable {
	void run();
}
