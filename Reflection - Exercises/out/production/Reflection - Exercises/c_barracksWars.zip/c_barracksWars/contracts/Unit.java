package c_barracksWars.contracts;

public interface Unit extends Destroyable, Attacker {
}
