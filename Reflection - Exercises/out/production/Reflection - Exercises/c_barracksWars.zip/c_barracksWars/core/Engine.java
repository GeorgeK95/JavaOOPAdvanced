package c_barracksWars.core;

import c_barracksWars.annotation.Alias;
import c_barracksWars.annotation.Inject;
import c_barracksWars.contracts.Executable;
import c_barracksWars.contracts.Repository;
import c_barracksWars.contracts.UnitFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class Engine implements Runnable {
    private static final String COMMANDS_PATH = "src/c_barracksWars/core/commands";
    private static final String COMMANDS_PACKAGE = "c_barracksWars.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public Engine(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        while (true) {
            try {
                String input = reader.readLine();
                String[] data = input.split("\\s+");
                String commandName = data[0];

                //task_4
               /*char firstLetter = Character.toUpperCase(commandName.charAt(0));
                String className = COMMANDS_PACKAGE + firstLetter + commandName.substring(1);
                Constructor<Executable> constructorCommand = (Constructor<Executable>) Class.forName(className)
                        .getDeclaredConstructor(String[].class, Repository.class, UnitFactory.class);
                constructorCommand.setAccessible(true);
                Executable executable = constructorCommand.newInstance(data, repository, unitFactory);*/

                Executable command = this.parseCommand(input, data, commandName);
                String result = command.execute();

                if (result.equals("fight")) {
                    break;
                }

                if (!result.equals("")) {
                    System.out.println(result);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private Executable parseCommand(String line, String[] data, String command) throws IOException {
        File commandsFolder = new File(COMMANDS_PATH);
        Executable executable = null;

        for (File file : commandsFolder.listFiles()) {
            if (!file.isFile() || !file.getName().endsWith(".java")) {
                continue;
            }
            try {
                String className = file.getName()
                        .substring(0, file.getName().lastIndexOf('.'));
                Class<Executable> exeClass = (Class<Executable>) Class.forName(COMMANDS_PACKAGE + className);

                if (!exeClass.isAnnotationPresent(Alias.class)) {
                    continue;
                }
                Alias alias = exeClass.getAnnotation(Alias.class);
                String value = alias.value();
                if (!value.equalsIgnoreCase(command)) {
                    continue;
                }

                Constructor exeCtor = exeClass.getConstructor(String.class, String[].class);
                executable = (Executable) exeCtor.newInstance(line, data);
                this.injectDependencies(executable, exeClass);

            } catch (ReflectiveOperationException rfe) {
                rfe.printStackTrace();
            }
        }

        return executable;
    }

    private void injectDependencies(Executable executable, Class<Executable> exeClass) throws ReflectiveOperationException {
        Field[] exeFields = exeClass.getDeclaredFields();
        for (Field fieldToSet : exeFields) {
            if (!fieldToSet.isAnnotationPresent(Inject.class)) {
                continue;
            }
            fieldToSet.setAccessible(true);

            Field[] theseFields = Engine.class.getDeclaredFields();
            for (Field thisField : theseFields) {
                if (!thisField.getType().equals(fieldToSet.getType())) {
                    continue;
                }
                thisField.setAccessible(true);
                fieldToSet.set(executable, thisField.get(this));
            }
        }
    }
}
