package Lab;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public class Main {
    public static void main(String[] args) {
      /*  Logger combat = new CombatLogger();
        Logger event = new EventLogger();
        combat.setSuccessor(event);

        combat.handle(LogType.ATTACK, "attack");
        combat.handle(LogType.ERROR, "error");
        combat.handle(LogType.EVENT, "event");*/
    }
}
