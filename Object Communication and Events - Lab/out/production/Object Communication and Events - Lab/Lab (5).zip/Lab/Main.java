package Lab;

import Lab.commands.AttackCommand;
import Lab.commands.CommandExecutor;
import Lab.commands.TargetCommand;
import Lab.contracts.Attacker;
import Lab.contracts.Command;
import Lab.contracts.Executor;
import Lab.contracts.Target;
import Lab.loggers.CombatLogger;
import Lab.loggers.EventLogger;
import Lab.loggers.Logger;
import Lab.models.Dragon;
import Lab.models.Warrior;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public class Main {
    public static void main(String[] args) {
        Logger combat = new CombatLogger();
        Logger event = new EventLogger();

        combat.setSuccessor(event);

        Attacker pesho = new Warrior("pesho", 10, combat);
        Target ivan = new Dragon("ivanchp", 100, 25, combat);

        Executor executor = new CommandExecutor();

        Command targetCommand = new TargetCommand(pesho, ivan);
        Command attackCommand = new AttackCommand(pesho);

       /* combat.handle(LogType.ATTACK, "attack");
        combat.handle(LogType.ERROR, "error");
        combat.handle(LogType.EVENT, "event");*/
    }
}
