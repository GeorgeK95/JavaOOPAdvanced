package Lab.contracts;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
