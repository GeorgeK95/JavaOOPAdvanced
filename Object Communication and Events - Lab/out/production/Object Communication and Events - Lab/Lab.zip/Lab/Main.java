package Lab;

import Lab.enums.LogType;
import Lab.loggers.BaseLogger;
import Lab.loggers.CombatLogger;
import Lab.loggers.EventLogger;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public class Main {
    public static void main(String[] args) {
        BaseLogger combat = new CombatLogger();
        BaseLogger event = new EventLogger();
        combat.setSuccessor(event);

        combat.handle(LogType.ATTACK, "attack");
        combat.handle(LogType.ERROR, "error");
        combat.handle(LogType.EVENT, "event");
    }
}
