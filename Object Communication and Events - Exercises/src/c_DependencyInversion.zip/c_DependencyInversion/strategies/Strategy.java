package c_DependencyInversion.strategies;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public interface Strategy {
    int calculate(int firstOperand, int secondOperand);
}
