package utils;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public interface RegistrationTime {
    Integer getHour();

    Integer getMinutes();

    Integer getDay();

    Integer getMonth();

    Integer getYear();

}
