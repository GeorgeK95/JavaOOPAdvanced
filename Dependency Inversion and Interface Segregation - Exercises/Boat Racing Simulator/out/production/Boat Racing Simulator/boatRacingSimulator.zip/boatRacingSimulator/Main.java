package boatRacingSimulator;

import boatRacingSimulator.Core.CommandHandler;
import boatRacingSimulator.Core.Engine;
import boatRacingSimulator.contracts.IBoatSimulatorController;
import boatRacingSimulator.controllers.BoatSimulatorController;

public class Main {
    public static void main(String[] args) {
        IBoatSimulatorController ctrl = new BoatSimulatorController();
        CommandHandler commandHandler = new CommandHandler(ctrl);
        Engine engine = new Engine(commandHandler, ctrl);
        engine.Run();
    }
}
