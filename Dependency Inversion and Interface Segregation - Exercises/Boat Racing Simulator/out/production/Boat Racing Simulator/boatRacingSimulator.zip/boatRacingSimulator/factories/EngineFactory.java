package boatRacingSimulator.factories;

import boatRacingSimulator.contracts.IEngine;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public class EngineFactory {
    static IEngine create(String model, int horsepower, int displacement, String engineType) {
        return null;
    }

}
