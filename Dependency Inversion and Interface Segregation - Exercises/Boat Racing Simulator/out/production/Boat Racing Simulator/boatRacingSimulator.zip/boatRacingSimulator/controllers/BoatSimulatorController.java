package boatRacingSimulator.controllers;

import boatRacingSimulator.Utility.Constants;
import boatRacingSimulator.contracts.*;
import boatRacingSimulator.database.BoatSimulatorDatabase;
import boatRacingSimulator.enumeration.EngineType;
import boatRacingSimulator.exeptions.*;
import boatRacingSimulator.models.boats.*;
import boatRacingSimulator.models.engines.JetEngine;
import boatRacingSimulator.models.engines.SterndriveEngine;
import boatRacingSimulator.models.race.Race;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BoatSimulatorController implements IBoatSimulatorController {
    private IDatabase database;
    private IRace currentRace;

    public BoatSimulatorController() {
        this.setDatabase(new BoatSimulatorDatabase());
        this.setCurrentRace(null);
    }

    @Override
    public IDatabase getDatabase() {
        return this.database;
    }

    private void setDatabase(IDatabase database) {
        this.database = database;
    }

    @Override
    public IRace getCurrentRace() {
        return this.currentRace;
    }

    private void setCurrentRace(IRace currentRace) {
        this.currentRace = currentRace;
    }

    @Override
    public String CreateBoatEngine(String model, int horsepower, int displacement, EngineType engineType) throws DuplicateModelException {
        IEngine engine = null;
        switch (engineType) {
            case JET:
                engine = new JetEngine(model, horsepower, displacement);
                break;
            case STERNDRIVE:
                engine = new SterndriveEngine(model, horsepower, displacement);
                break;
        }

        this.database.getEngines().Add(engine);
        return String.format(
                "Engine model %s with %s HP and displacement %s cm3 created successfully.",
                model,
                horsepower,
                displacement);
    }

    public String CreateRowBoat(String model, int weight, int oars) throws DuplicateModelException {
        IBoat boat = new RowBoat(model, weight, oars/*, oars, 1, new ArrayList<JetEngine>(), new ArrayList<SterndriveEngine>(), false*/);
        this.database.getBoats().Add(boat);
        return String.format("Row boat with model %s registered successfully.", model);
    }

    public String CreateSailBoat(String model, int weight, int sailEfficiency) throws DuplicateModelException {
        IBoat boat = new SailBoat(model, weight, sailEfficiency/*, 1, 1, new ArrayList<JetEngine>(), new ArrayList<SterndriveEngine>(), true*/);
        this.database.getBoats().Add(boat);
        return String.format("Sail boat with model %s registered successfully.", model);
    }

    public String CreatePowerBoat(String model, int weight, String firstEngineModel, String secondEngineModel) throws NonExistantModelException, DuplicateModelException {
        IEngine firstEngine = this.database.getEngines().GetItem(firstEngineModel);
        IEngine secondEngine = this.database.getEngines().GetItem(secondEngineModel);
        IBoat boat = new PowerBoat(model, weight, firstEngine, secondEngine);
        this.database.getBoats().Add(boat);
        return String.format("Power boat with model %s registered successfully.", model);
    }

    public String CreateYacht(String model, int weight, String engineModel, int cargoWeight) throws NonExistantModelException, DuplicateModelException {
        IEngine engine = this.database.getEngines().GetItem(engineModel);
        IBoat boat = new Yacht(model, weight, engine, cargoWeight);
        this.database.getBoats().Add(boat);
        return String.format("Yacht with model %s registered successfully.", model);
    }

    public String OpenRace(int distance, int windSpeed, int oceanCurrentSpeed, Boolean allowsMotorboats) throws NoSetRaceException, RaceAlreadyExistsException {
        this.ValidateRaceAlreadySet();
        this.currentRace = new Race(distance, windSpeed, oceanCurrentSpeed, allowsMotorboats);
        this.currentRace.setSet();
        return String.format("A new race with distance %s meters, wind speed %s m/s and ocean current speed %s m/s has been set.",
                distance, windSpeed, oceanCurrentSpeed);
    }

    public String SignUpBoat(String model) throws NonExistantModelException, DuplicateModelException, NoSetRaceException {
        IBoat boat = this.database.getBoats().GetItem(model);
        this.ValidateRaceIsSet();

        if (!this.currentRace.getAllowsMotorboats() && boat.hasEngine()) {
            throw new IllegalArgumentException(Constants.IncorrectBoatTypeMessage);
        }
       /* Class<?>[] stream = boat.getClass().getInterfaces();
        final boolean[] isEngineType = {false};
        Arrays.stream(stream).forEach(x -> isEngineType[0] = x.getSimpleName().equals("IEngineType"));

        if (!this.currentRace.getAllowsMotorboats() && isEngineType[0]) {
            throw new IllegalArgumentException(Constants.IncorrectBoatTypeMessage);
        }*/

        this.currentRace.AddParticipant(boat);
        return String.format("Boat with model %s has signed up for the current Race.", model);
    }

    @Override
    public String StartRace() throws InsufficientContestantsException, NoSetRaceException {
        this.ValidateRaceIsSet();
        List<IBoat> participants = this.currentRace.GetParticipants();
        this.ValidateRaceIsEmpty(participants);

        Comparator<IBoat> bySpeedDescending = (b1, b2) -> {
            double s1 = b1.CalculateRaceSpeed(this.currentRace);
            double s2 = b2.CalculateRaceSpeed(this.currentRace);
            if (s1 < 0 && s2 < 0) {
                return 0;
            }
            return Double.compare(s2, s1);
        };
        List<IBoat> winners = participants.stream()
                .sorted(bySpeedDescending)
                .limit(3)
                .collect(Collectors.toList());

        StringBuilder result = new StringBuilder();
        int placeCounter = 1;
        for (IBoat winner : winners) {
            double speed = winner.CalculateRaceSpeed(this.currentRace);
            double time = this.currentRace.getDistance() / speed;
            result.append(placeCounter == 1 ? "First" : placeCounter == 2 ? "Second" : "Third")
                    .append(" place: ").append(winner.getClass().getSimpleName())
                    .append(" Model: ").append(winner.getModel())
                    .append(" Time: ").append(speed <= 0D ? "Did not finish!" : String.format("%.2f sec", time))
                    .append(System.lineSeparator());
            placeCounter++;
        }

        this.currentRace = null;
        return result.toString().trim();
    }


 /*   private String generateOutput(Map<Double, List<IBoat>> finished, Map<Double, List<IBoat>> nonFinished) {
        String[] places = new String[]{"First", "Second", "Third"};
        int index = 0;
        StringBuilder result = new StringBuilder();
        index = this.appendParticipants(finished, result, places, index);
        this.appendParticipants(nonFinished, result, places, index);
        return result.toString();
    }*/

  /*  private int appendParticipants(Map<Double, List<IBoat>> participants, StringBuilder result, String[] places, int index) {
        for (Map.Entry<Double, List<IBoat>> doubleIBoatEntry : participants.entrySet()) {
            for (IBoat iBoat : doubleIBoatEntry.getValue()) {
                String simpleName = iBoat.getClass().getSimpleName();
                String model = iBoat.getModel();
                result.append(String.format("%s place: %s Model: %s Time: %s", places[index], simpleName, model, isFinished(doubleIBoatEntry.getKey())))
                        .append(System.lineSeparator());
                index++;
            }
        }
        return index;
    }

    private void FindFastest(List<IBoat> participants, HashMap<Double, List<IBoat>> finished, HashMap<Double, List<IBoat>> nonFinished) {
        Double bestTime = Double.MAX_VALUE;
        IBoat winner = null;
        for (IBoat participant : participants) {
            Double speed = participant.CalculateRaceSpeed(this.currentRace);
            Double time = this.currentRace.getDistance() / speed;
            if (time < bestTime) {
                bestTime = time;
                winner = participant;
            }
        }

        if (bestTime <= 0) {
            nonFinished.putIfAbsent(bestTime, new ArrayList<>());
            if (nonFinished.containsKey(bestTime)) {
                List<IBoat> temp = nonFinished.get(bestTime);
                temp.add(winner);
                nonFinished.put(bestTime, temp);
            }
        } else {
            finished.putIfAbsent(bestTime, new ArrayList<>());
            if (finished.containsKey(bestTime)) {
                List<IBoat> temp = finished.get(bestTime);
                temp.add(winner);
                finished.put(bestTime, temp);
            }
        }

        participants.remove(winner);
    }*/

    private void ValidateRaceIsEmpty(List<IBoat> participants) throws InsufficientContestantsException {
        if (participants.size() < 3) {
            throw new InsufficientContestantsException(Constants.InsufficientContestantsMessage);
        }
    }

/*    private String isFinished(Double key) {
        if (key <= 0) {
            return "Did not finish!";
        }
        return String.format("%.2f sec", key);
    }*/

    @Override
    public String GetStatistic() throws NoSetRaceException {
        if (this.currentRace == null) {
            throw new NoSetRaceException(Constants.NoSetRaceMessage);
        }

        List<IBoat> participants = this.currentRace.GetParticipants();
        Map<String, List<IBoat>> participantsByBoatType = participants.stream().collect(Collectors.groupingBy((p) -> p.getClass().getSimpleName()));
        int totalParticipants = participantsByBoatType.values().stream().mapToInt(List::size).sum();

        StringBuilder sb = new StringBuilder();
        participantsByBoatType.entrySet().stream()
                .sorted((e1, e2) -> e1.getKey().compareTo(e2.getKey()))
                .forEach((e) -> {
                    sb.append(String.format("%s -> %.2f", e.getKey(), 100D * e.getValue().size() / totalParticipants));
                    sb.append("%").append(System.lineSeparator());
                });
        return sb.toString().trim();
//        return null;
    }

  /*  public String getStatistic() {
        //TODO Bonus Task Implement me
        throw new NotImplementedException();
    }*/

    private void ValidateRaceIsSet() throws NoSetRaceException {
        if (this.currentRace == null) {
            throw new NoSetRaceException(Constants.NoSetRaceMessage);
        }
    }

    private void ValidateRaceAlreadySet() throws RaceAlreadyExistsException {
        if (this.currentRace != null) {
            throw new RaceAlreadyExistsException(Constants.RaceAlreadyExistsMessage);
        }
    }
}
