package boatRacingSimulator.Core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Engine implements Runnable {
    private CommandHandler commandHandler;
    private BufferedReader reader;

    public Engine(CommandHandler commandHandler) {
        this.reader = new BufferedReader(new InputStreamReader(System.in));
        this.commandHandler = commandHandler;
    }

    public void run() {
        StringBuilder builder = new StringBuilder();

        while (true) {
            try {
                String input = reader.readLine();
                if ("End".equals(input)) {
                    break;
                }

                String[] arguments = input.split("\\\\");
                String commandResult = this.commandHandler.ExecuteCommand(arguments[0], Arrays.asList(arguments).subList(1, arguments.length));
                builder.append(commandResult).append(System.lineSeparator());
            } catch (Exception exception) {
                builder.append(exception.getMessage()).append(System.lineSeparator());
            }
        }

        if (builder.length() > 0) {
            System.out.println(builder.toString().trim());
        }
    }
}
