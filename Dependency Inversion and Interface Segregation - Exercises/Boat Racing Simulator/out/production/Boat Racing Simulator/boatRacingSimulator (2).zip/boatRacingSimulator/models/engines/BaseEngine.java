package boatRacingSimulator.models.engines;

import boatRacingSimulator.Utility.Constants;
import boatRacingSimulator.Utility.Validator;
import boatRacingSimulator.contracts.IEngine;

/**
 * Created by George-Lenovo on 6/29/2017.
 */
public abstract class BaseEngine implements IEngine {
    private String model;
    private int horsepower;
    private int displacement;
    private int cachedOutput;

    public BaseEngine(String model, int horsepower, int displacement) {
        this.setModel(model);
        this.setHorsepower(horsepower);
        this.setDisplacement(displacement);
    }

    @Override
    public int getHorsepower() {
        return horsepower;
    }


    @Override
    public int getDisplacement() {
        return displacement;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public int getCachedOutput() {
        return cachedOutput;
    }

    public void setModel(String model) {
        Validator.ValidateModelLength(model, Constants.MinBoatEngineModelLength);
        this.model = model;
    }

    public void setHorsepower(int horsepower) {
        Validator.ValidatePropertyValue(horsepower, "Horsepower");
        this.horsepower = horsepower;
    }

    public void setDisplacement(int displacement) {
        Validator.ValidatePropertyValue(displacement, "Displacement");
        this.displacement = displacement;
    }


    public void setCachedOutput(int cachedOutput) {
        this.cachedOutput = cachedOutput;
    }
}
