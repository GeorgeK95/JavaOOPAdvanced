package boatRacingSimulator.enumeration;

public enum EngineType {
    JET, STERNDRIVE;
}
